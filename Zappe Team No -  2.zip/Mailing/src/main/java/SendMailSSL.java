public class SendMailSSL{
    public static void main(String[] args) {
        //from,password,to,subject,message
        Mailer.send("dream11.arunj.10@gmail.com","9894174924","16eucs029@skcet.ac.in","hello javatpoint","How r u?");
        //change from, password and to
    }
}

